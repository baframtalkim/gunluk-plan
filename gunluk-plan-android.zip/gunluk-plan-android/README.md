# Günlük Plan – Android (WebView) uygulaması

Bu proje, gunluk-plan-asistani.html dosyasını (app/src/main/assets/index.html) bir Android uygulaması içinde çalıştırır.
Veriler (planlar, yüklenen dosyalar, ders kitabı, ayarlar) uygulamanın dosya klasörüne yazılır ve uygulama kapansa da kalır.
PDF/DOCX/yedek dosyaları telefonun İndirilenler klasörüne kaydedilir.

## Yol 1 – Android Studio (bilgisayar)
1. Klasörü Android Studio ile açın, Gradle eşitlemesini bekleyin.
2. Build > Build APK(s) ile app-debug.apk üretin, telefona kurun.

## Yol 2 – Yalnızca telefon + GitHub (ücretsiz, bulutta derleme)
1. github.com'da yeni bir depo açın.
2. Bu klasördeki tüm dosyaları depoya yükleyin (Add file > Upload files).
   .github/workflows/build.yml dosyasını yüklemek zorsa: Add file > Create new file, dosya adına
   `.github/workflows/build.yml` yazıp içeriği yapıştırın.
3. Actions sekmesi > "APK derle" > son çalışmayı açın (yeşil tik çıkana kadar 3-6 dk bekleyin).
4. Sayfanın altındaki Artifacts bölümünden GunlukPlan-apk dosyasını indirin, zip'ten çıkarıp app-debug.apk'yı kurun
   ("bilinmeyen kaynaklardan yükleme" izni gerekir).

Not: pdf.js, mammoth, docx ve html2pdf kütüphaneleri internetten (CDN) yüklenir; ilk kullanımda internet gerekir.
Uygulamayı kaldırırsanız verileri de silinir; bu yüzden Ayarlar > Yedek dosyası indir ile düzenli yedek alın.
